int main_msc(void);

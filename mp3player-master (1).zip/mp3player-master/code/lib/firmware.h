int load_fw(char * filename);
void call_firmware(void);
